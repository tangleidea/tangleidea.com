<?php 
$vpath = "https://".$_SERVER['HTTP_HOST']."/";
$phone = "+1 (888) 374-8009"; 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<html lang="en-gb" class="no-js">
<head>


<meta name="trafficjunky-site-verification" content="qya1x3qnt" />


<meta charset="UTF-8">
<title>Website Design Company </title>
<meta name="google-site-verification" content="6SAtFgEa4WMFwwERyR3tgFrQCQnBM755skBhsQotiW8" />
<meta name="description" content="Tangle Idea is the most recommended Web Design and Development Company in the world. Call Us: 9903006088 for innovative and professional website design team, Sumit Mandal" />
<meta name="keywords" content="Web Designer, Web Developer, website design company in the world, web design company in USA, web development company in India, website development company in UK" />
<meta name="robots" content="index, follow" />
<meta name="language" content="EN" />
<meta name="organization" content="Tangle Idea" />
<link rel="author" href="https://plus.google.com/108938508198569677848"/>
<link rel="publisher" href="https://plus.google.com/collection/EOu2GE"/>	
<link rel="canonical" href="home" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Website Design Company in the World – Tangle Idea" />
<meta property="og:description" content="Tangle Idea is the most recommended Web Development Company in the world. Call Us: 9903006088 for innovative and professional website design team. Call Us: +91 9903006088 / +91 9903006088" />
<meta property="og:image" content="images/logo.png"/>
<meta property="og:url" content="home" />
<meta property="og:site_name" content="Tangle Idea" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">

<link href="css/style.css" rel="stylesheet" type="text/css">

<link href="css/responsive.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/slider/swiper.min.css">
<link rel="stylesheet" href="layerslider/css/layerslider.css" type="text/css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/home.min.css">
<script type="text/javascript" src="SEOTools.js"></script>
<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="js/slider/swiper.min.js"></script>
<script type="text/javascript" defer="defer" src="js/wow.min.js"></script>
<script type="text/javascript" defer="defer" src="js/bootstrap.min.js"></script>
<script type="text/javascript" defer="defer" src="js/jquery.sticky.js"></script>
<script type="text/javascript" defer="defer" src="js/jquery.isotope.min.js"></script>
<script type="text/javascript" defer="defer" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" defer="defer" src="js/modernizr.js"></script>
<script type="text/javascript" defer="defer" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" defer="defer" src="js/waypoints.min.js"></script>
<script type="text/javascript" defer="defer" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" defer="defer" src="js/bootstrap-hover-dropdown.min.js"></script>
<script type="text/javascript" defer="defer" src="layerslider/js/greensock.js"></script>
<script src="layerslider/js/layerslider.transitions.js" type="text/javascript"></script>
<script src="layerslider/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
<script type="text/javascript" defer="defer" src="js/main.min.js"></script>


<!--Google Analytics-->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-98684756-1', 'auto');
  ga('send', 'pageview');

</script>
<!--Google Analytics End-->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-129069839-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-129069839-1');
</script>


<!--    Right Click protection  Start   --->
<script>
/*
       var isCtrl = false;
        document.onkeyup = function (e)
        {
            if (e.which == 17)
                isCtrl = false;
        }
       
        var isNS = (navigator.appName == "Netscape") ? 1 : 0;
        if (navigator.appName == "Netscape")
            document.captureEvents(Event.MOUSEDOWN || Event.MOUSEUP);
        function mischandler() {
            return false;
        }
        function mousehandler(e) {
            var myevent = (isNS) ? e : event;
            var eventbutton = (isNS) ? myevent.which : myevent.button;
            if ((eventbutton == 2) || (eventbutton == 3))
                return false;
        }
        document.oncontextmenu = mischandler;
        document.onmousedown = mousehandler;
        document.onmouseup = mousehandler;
*/
</script>
<!--  ///  Right Click protection  End   --->

<!--    Google adsence     -->

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-2593148458071520",
    enable_page_level_ads: true
  });
</script>

<script async custom-element="amp-auto-ads"
        src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js">
</script>

<amp-auto-ads type="adsense"
              data-ad-client="ca-pub-2593148458071520">
</amp-auto-ads>



<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script> <script> (adsbygoogle = window.adsbygoogle || []).push({ google_ad_client: "ca-pub-2593148458071520", enable_page_level_ads: true }); </script>

<!--    Google adsence  END   -->


</head>
<body>




<?php

function active($currect_page){
  $url_array =  explode('/', $_SERVER['REQUEST_URI']) ;
  $url = end($url_array);  
  if($currect_page == $url){
      echo 'active'; //class name in css 
  } 
}

?>
<div id="wrap">
<header class="sticky">
<div class="container">
<div class="menu">
<div class="logo"> <a href="<?=$vpath?>"> <img src="images/logo.png" class="img-responsive" alt="Logo"> </a> </div>
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="fa fa-bars"></span> </button>
</div>
<div class="top-header-box"> <a class="btn btn-green-border btn-lg" href="get-quote"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Request Quotation</a>
	<a href="tel:<?=$phone?>">
<span class="number" style="color:#FFFFFF;"> <i class="fa fa-mobile" aria-hidden="true"></i> <?=$phone?> </span> </a></div>
<nav class="navbar navbar-default" role="navigation">
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav">
<li class="<?php active('home');?>"> <a href="<?=$vpath?>"> Home</a> </li>
<li class="<?php active('about_us');?>"><a href="about_us">About Us</a></li>
<li class="dropdown"><a href="#" class="dropdown-toggle" data-hover="dropdown" data-delay="100">Services<b class="caret"></b></a>
<ul class="dropdown-menu">
<li><a href="web-design-development-services"> Web Design &amp; Development</a></li>
<li><a href="ecommerce-web-development">Ecommerce Development</a></li>

<li><a href="software-development-company">Software Development</a></li>
<li><a href="digital-marketing">Complet Digital marketing</a></li>
<li><a href="seo-services">Seo Service</a></li>
<li><a href="hire-seo-expert">Hire Dedicated SEO Experts</a></li>
</ul>
</li>
<li class="<?php active('portfolio');?>"><a href="portfolio">Portfolio</a> </li>

<!-- <li class="<?php active('themes');?>"><a href="themes">Theme</a> </li>  -->

<li class="<?php active('contact');?>"><a href="contact">Contact Us </a></li>


</ul>
</div>
</nav>
<div class="clearfix"></div>
<div class="header_shadow"> <span class=""></span> </div>
</div>
</div>
</header>