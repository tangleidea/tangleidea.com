<?php include("include/header.php"); ?>
  
  <!--HOME START===========================================-->
  
<div class="inner-banner5">
            <div class="tittle">

                    <h1>Amazon Prime Customer Service</h1>

            </div>
        </div>


 <section id="website" class="mobile-apps">
    <div class="container">
      <div class="tittle">
         <h2>Amazon Prime phone Customer Service <br>How can we help you?</h2>
        <hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
      </div>
 <br><br>
        <a href="tel:<?=$phone?>"><h2><i class="fa fa-phone" aria-hidden="true"></i>
   <?=$phone?></h2></a>
     
     
      
    </div>
  </section>

<br><br><br><br><br>

  <section id="website" class="mobile-apps">
    <div class="container">
      <div class="tittle">
        
        <hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
      </div>
  
       <p>Being a leader in anything brings you better feeling, but it also brings you loads of responsibilities. Tangle Idea enjoys being the leader in the field of Software Development Services in India. However, it realizes the responsibilities as well. We accept the fact that development of software is a challenging task that has all sorts of technicalities. Meeting all such aspects often creates problems for the people. However, Tangle Idea has full trust on its highly-skilled developers who have proved their skills again and again.  The company has an experience of more than 5 years, and these years have brought us invaluable knowledge and expertise. Today, we find us more competitive, and put us ahead of all our rivals. We are confident about meeting all the standards that you have in your mind for your own business.</p>
     
      <div class="col-lg-12 ecom">
        <div class="img wow fadeInUp"> <img src="images/software-development.png" alt="Software Development" ></div>
      </div>
      
    </div>
  </section>
  
  
  
 <!--- 
  
<section id="about" class="our-works text-center android">
            
                <div class="tittle">
                    <h3>Some of our customized software</h3>
                    <hr class="wow bounceInUp animated" data-wow-duration="1s" data-wow-delay="0.7s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.7s; animation-name: bounceInUp;">
                    <p>we produce awesome work for our clients according to their budget and time frame</p>
                </div>
                <div class="portfolio-wrapper project">
<!-- Swiper -->
 <!---     <div class="images"> <img src="images/slide/Monitor-PNG-Picture.png" alt="software bg" class="img-responsive"></div>
    <div class="swiper-container">
       
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="images/slide/soft/slide1.jpg" alt="software works" class="img-responsive"></div>
            
        </div>
        <div class="swiper-pagination"></div>
    </div>
                    
                </div>
                 <a class="btn mt-150" href="portfolio.html">View Portfolio</a>
            
        </section>
--->

      <section id="software" class="reason">
  <div class="tittle">
    <h4>Why Tangle Idea is the best Software Development company in kolkata! </h4>
    <hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
    </div>
    <div class="container">
      <div class="col-lg-12">
    <p>Tangle Idea is here with the latest and best available technologies including PHP, Flex, ASP.net, jQuery, Flash Ajax, and MySQL, to accelerate your business needs. Our Software developers dedicate themselves to think and to develop attractive, result-oriented, fast-loading, search engine optimized websites and customer centric software with easy and user-friendly navigation.</p>
    </div>
    </div>

    <div class="container">
      <div class="col-lg-12">

        <div class="col-lg-8"><p> <i class="fa fa-check-square-o icon_right"></i> Team of Highly-Professional Software Developers</p>



<p><i class="fa fa-check-square-o icon_right"></i> Strategy to Support Customer-Friendly Projects.</p>

<p><i class="fa fa-check-square-o icon_right"></i> Constant Communication.</p>

<p><i class="fa fa-check-square-o icon_right"></i> Supported with the Latest Technology.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Proven Methodologies.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Top-notch Security Facilities.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Highly Cost effective.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Implementation and Testing Methodologies.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Timely Delivery with No Missed Deadlines.</p>
        </div>
        <div class="col-lg-4">
       <img src="images/seo-reason.png" alt="seo services" class="img-responsive">
        </div>
        
      </div>
    </div>
  </section>

        <section class="about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="special-text">Whenever it comes to <strong>software development </strong>services, <strong>Tangle Idea</strong>, becomes the <strong>obvious choice.</strong></p>
                        <p class="special-text"><strong>Contact us</strong>, right away and get <strong>customize software!</strong>
                        </p>
                        <p class="special-text">Would you like to work with the <strong>leaders in Software Development?</strong> </p>

<?php include("include/footer.php");
		include("include/footer_botom.php"); ?>