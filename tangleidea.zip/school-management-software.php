<?php include("include/header.php"); ?>
			
			<!--HOME START===========================================-->


 <div class="inner-banner5">
            <div class="tittle">

                    <h1>School Management Software Kolkata</h1>

            </div>
        </div>

			<section id="website" class="mobile-apps bg-white">
				<div class="container">
					<div class="tittle">
					
						<hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
					</div>
					

<p>Are you running an educational institution or a school of your own in Kolkata? 
Are you finding it difficult to manage and update the databases on a regular basis? 
Do you want to get a break-through here? </p> 
<p>If your answers are affirmative, then you have landed the best place on the Internet that can bring you the best school management development facilities. Tangle Idea has been successful in finding highly-efficient school management software that can solve all your problems that you have been facing these days. With the help of the software, you can easily manage the databases for students, teachers, and other staff in your school. This is not all, you can also solve all your existing accounting problems. Within just a few weeks of using the software, you can feel the differences all by yourself.</p> 			
                        
</div>
</section>


                    

</section>

            



  <section id="software" class="reason">
  <div class="tittle">
    <h3>Salient Features of Our School Management Software</h3>
    <hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
    </div>
    <div class="container">
      <div class="col-lg-12">
      <p>Tangle Idea shares its technical expertise by introducing the wonderful School Management Development software in the World. No matter your institution is small or big, you can get rid of all the problems that make you worried quite often. The trusted technology has been tested by a large number of educational institutes locally and globally. It is your turn to add the power of technology to your school business.  Do it today!</p>
      </div>
      </div>

    <div class="container">
      <div class="col-lg-12">

        <div class="col-lg-8"><p> <i class="fa fa-check-square-o icon_right"></i> Systematized as well as potent school management software can efficiently cater improved learning experience to the students. </p>

<p><i class="fa fa-check-square-o icon_right"></i> With the help of the Parent portal feature, parents can actively contribute to their children’s different educational activities.</p>

<p><i class="fa fa-check-square-o icon_right"></i> Managing the attendance of the students without making any kind of errors has become much easier using the online attendance sheets.</p>

<p><i class="fa fa-check-square-o icon_right"></i> Any report regarding a student’s exam results, class performance and attendance are available online on the portal.</p>

<p><i class="fa fa-check-square-o icon_right"></i> Efficient as well as effective school management software is capable enough to generate online receipt of the school fees.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Payment of school fees can be done online that makes this entire tedious process hassle-free.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Easy-To-Use Interface.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Built With the Latest Technology.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Assured Safety to Your Intellectual Property.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Facilitated with Required Features.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Available in Both Tab and Mobile Versions.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Easily Customizable As Per Your Extended Requirement
</p>
<p><i class="fa fa-check-square-o icon_right"></i> Affordable Price.</p>
<p><i class="fa fa-check-square-o icon_right"></i> Trusted  24*7 Support
</p>
        </div>
        <div class="col-lg-4">
       <img src="images/seo-reason.png" alt="seo services" class="img-responsive">
        </div>
        
      </div>
    </div>
  </section>

        <section class="about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="special-text">Do you want to develop an <strong>efficient </strong>and <strong>effective</strong> School Management Software?</p>
                        <p class="special-text"><strong>Contact</strong> us today and experience <strong>class and quality encased beneath one roof!
</strong>
                        </p>
                        <p class="special-text">Would you like to <strong>work with us?</strong> </p>

<?php include("include/footer.php");
		include("include/footer_botom.php"); ?>