
<p class="special-text">Call us now <strong class="phone"><?=$phone?></strong> or</p>
<a class="btn" href="get-quote">Request Quotation</a>
</div>
</div>
</div>
</section>
