
<div class="rights">
<div class="container">
<div class="col-lg-4 copyright">
<p>
Copyright © 2017 Tangle Idea.
</p>
</div>
<div class="col-lg-5">
<ul class="nav navbar-nav">
<li>
<a href="terms-condition"> Terms & Condition</a>
</li>
<li>
<a href="privacy-policy"> Privacy & Policy</a>
</li>

<li>
<a href="contact">Contact Us </a>
</li>

</ul>
</div>

 
<div class="col-lg-3 social">
<ul class="social-nav model-6">
 <li>
  <a href="https://www.facebook.com/Tangle-Idea-1861285724119801/" class="facebook" target="_blank" rel="nofollow"> <i class="fa fa-facebook"></i>
 </a>
 </li>
 <li><a href="https://plus.google.com/108938508198569677848" class="google-plus" target="_blank" rel="nofollow"><i class="fa fa-google-plus"></i></a>
 </li>
 
<li><a href="https://twitter.com/IdeaTangle" class="twitter" target="_blank"><i class="fa fa-twitter" rel="nofollow"></i></a>
</li>
<li><a href="https://www.linkedin.com/in/tangle-idea-716316175/" class="linkedin" target="_blank" rel="nofollow"><i class="fa fa-linkedin"></i></a>
</li>
<li><a href="https://www.youtube.com/channel/" class="youtube" target="_blank" rel="nofollow"><i class="fa fa-youtube" aria-hidden="true"></i></a>
</li>	
	
</ul>
</div>


</div>
</div>
</div>
</div>

<a href="#" class="scrollup" style="display:none">Scroll</a>
<script type="text/javascript" defer="defer" >var swiper=new Swiper(".swiper-container",{pagination:".swiper-pagination",nextButton:".swiper-button-next",prevButton:".swiper-button-prev",paginationClickable:true,spaceBetween:30,effect:"fade",centeredSlides:true,autoplay:1500,autoplayDisableOnInteraction:false});</script>
<script type="text/javascript" defer="defer">jQuery("#layerslider").layerSlider({responsive:false,responsiveUnder:1280,layersContainer:1280,pauseOnHover:false,skinsPath:"layerslider/skins/"});</script>
<script type="text/javascript" defer="defer">$(document).ready(function(){$(window).scroll(function(){if($(this).scrollTop()>100){$(".scrollup").fadeIn()}else{$(".scrollup").fadeOut()}});$(".scrollup").click(function(){$("html, body").animate({scrollTop:0},600);return false})});</script>

<script type="text/javascript" defer="defer">
jQuery(document).ready(function($){
	//create the slider
	$('.cd-testimonials-wrapper').flexslider({
		selector: ".cd-testimonials > li",
		animation: "slide",
		controlNav: false,
		slideshow: false,
		smoothHeight: true,
		start: function(){
			$('.cd-testimonials').children('li').css({
				'opacity': 1,
				'position': 'relative'
			});
		}
	});

	//open the testimonials modal page
	$('.cd-see-all').on('click', function(){
		$('.cd-testimonials-all').addClass('is-visible');
	});

	//close the testimonials modal page
	$('.cd-testimonials-all .close-btn').on('click', function(){
		$('.cd-testimonials-all').removeClass('is-visible');
	});
	$(document).keyup(function(event){
		//check if user has pressed 'Esc'
    	if(event.which=='27'){
    		$('.cd-testimonials-all').removeClass('is-visible');	
	    }
    });
    
	//build the grid for the testimonials modal page
	$('.cd-testimonials-all-wrapper').children('ul').masonry({
  		itemSelector: '.cd-testimonials-item'
	});
});
</script>






</body>

</html>