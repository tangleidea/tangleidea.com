<?php include("include/header.php"); ?>

<div id="layerslider" style="width:100%;height:650px">
<div class="ls-layer" id="layer2" style="slidedelay:6000;transition2d:all">
<img class="ls-bg" src="images/slide/back_ar.png" alt="layer1-background">
<img class="ls-s-1" style="left:-100px;top:100px;slidedirection:left;durationin:2000;easingin:easeoutexpo;delayin:0;slideoutdirection:bottom;durationout:1000;easingout:easeinsine;scaleout:1" src="images/device.png" alt="layer1-sublayer1">
<p class="ls-s-1" style="left:550px;top:196px;slidedirection:fade;easingin:easeoutsine;delayin:500;font-weight:600;font-size:45px;font-family:'Roboto-Thin';color:#fff;text-shadow:0 1px 1px #000">WEB DESIGN &amp; DEVELOPMENT </p>
<p class="ls-s-1" style="left:550px;top:276px;slidedirection:fade;easingin:easeoutsine;delayin:800;font-weight:400;font-family:'Roboto-Thin';font-size:34px;color:#fff;text-shadow:0 1px 1px #000">Add the winning edge with creative website</p>

<a href="web-design-development-services.php" target="_self" class="ls-s-1-linkto-1" style="left:550px;top:400px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1000;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #fff;border-radius:2px">VIEW DETAILS</a>
<a href="portfolio.php" target="_self" class="ls-s-1-linkto-1" style="left:770px;top:400px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1400;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #0085c3;background-color:#0085c3;border-radius:2px">SEE PORTFOLIO</a> </div>
<div class="ls-layer" style="slidedelay:6000;transition2d:all">
<img class="ls-bg" src="images/slide/back_ar.png" alt="layer1-background">
<img class="ls-s-1" style="left:0;top:100px;slidedirection:left;durationin:2000;easingin:easeoutexpo;delayin:0;slideoutdirection:bottom;durationout:1000;easingout:easeinsine;scaleout:1" src="images/device-2.png" alt="layer1-sublayer1">
<p class="ls-s-1" style="left:550px;top:196px;slidedirection:top;padding:14px 17px 14px 31px;easingin:easeoutsine;delayin:0;font-weight:600;font-family:'Roboto-Thin';text-align:center;font-size:45px;color:#fff;text-shadow:0 1px 1px #000">MOBILE APP DEVELOPMENT </p>
<p class="ls-s-1" style="left:550px;top:276px;slidedirection:bottom;padding:14px 17px 14px 31px;easingin:easeoutsine;delayin:0;font-weight:400;font-family:'Roboto-Thin';text-align:center;font-size:34px;color:#fff;text-shadow:0 1px 1px #000">Launch your business in mobile domain
</p>

<a href="mobile-app-development.php" target="_self" class="ls-s-1-linkto-1" style="left:580px;top:400px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1000;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #fff;border-radius:2px">VIEW DETAILS</a>
<a href="portfolio.php" target="_self" class="ls-s-1-linkto-1" style="left:800px;top:400px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1400;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #0085c3;background-color:#0085c3;border-radius:2px">SEE PORTFOLIO</a> </div>
<div class="ls-layer" id="layer3" style="slidedelay:6000;transition2d:all">
<img class="ls-bg" src="images/slide/back_ar.png" alt="layer1-background">
<img class="ls-s-1" style="left:416.5px;top:100px;slidedirection:right;durationin:2000;easingin:easeoutexpo;delayin:0;slideoutdirection:bottom;durationout:1000;easingout:easeinsine;scaleout:1" src="images/device-1.png" alt="layer1-sublayer1">
<p class="ls-s-1" style="left:70px;top:175px;slidedirection:fade;easingin:easeoutsine;delayin:500;font-weight:600;font-family:'Roboto-Thin';font-size:45px;color:#fff;text-shadow:0 1px 1px #000">ECOMMERCE WEB DEVELOPMENT </p>
<p class="ls-s-1" style="left:70px;top:250px;slidedirection:fade;easingin:easeoutsine;delayin:800;font-weight:400;font-family:'Roboto-Thin';font-size:34px;color:#fff;text-shadow:0 1px 1px #000">Expand your business with top eCommerce solution</p>

<a href="ecommerce-web-development.php" target="_self" class="ls-s-1-linkto-1" style="left:70px;top:370px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1200;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #fff;border-radius:2px">VIEW DETAILS</a>
<a href="portfolio.php" target="_self" class="ls-s-1-linkto-1" style="left:290px;top:370px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1600;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #0085c3;background-color:#0085c3;border-radius:2px">SEE PORTFOLIO</a> </div>
<div class="ls-layer" id="layer1" style="slidedelay:6000;transition2d:all">
<img class="ls-bg" src="images/slide/back_ar.png" alt="layer1-background">
<img class="ls-s-1" style="left:416.5px;top:100px;slidedirection:left;durationin:2000;easingin:easeoutexpo;delayin:0;slideoutdirection:bottom;durationout:1000;easingout:easeinsine;scaleout:1" src="images/device-3.png" alt="layer1-sublayer1">
<p class="ls-s-1" style="top:175px;left:70px;font-family:'Roboto-Thin';text-align:center;font-size:45px;color:#fff;font-weight:600;slidedirection:top;durationin:500;easingin:easeoutexpo;delayin:500;slideoutdirection:fade;durationout:1000;text-shadow:0 1px 1px #000">SEO SERVICES</p>
<p class="ls-s-1" style="left:70px;top:250px;slidedirection:fade;easingin:easeoutsine;delayin:800;font-weight:400;font-family:'Roboto-Thin';text-align:center;font-size:34px;color:#fff;text-shadow:0 1px 1px #000">Get your website at the 1st page of google search result
</p>

<a href="seo-services.php" target="_self" class="ls-s-1-linkto-1" style="left:70px;top:370px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1200;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #fff;border-radius:2px">VIEW DETAILS</a>
<a href="portfolio.php" target="_self" class="ls-s-1-linkto-1" style="left:290px;top:370px;scalein:0;slidedirection:fade;easingin:easeoutexpo;delayin:1600;font-weight:300;font-size:18px;color:#fff;padding:11px 40px;border:1px solid #0085c3;background-color:#0085c3;border-radius:2px">SEE PORTFOLIO</a></div>
</div>


<div class="content">
<section id="intro">
<div class="container">
<div class="tittle">
<p class="special">Welcome to Tangle Idea</p>
<hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
<h1>A professional web design &amp; development company in the World </h1>
<p>Being a leading web design and development company based in the World, Tangle Idea has been providing the best and cost effective web solutions to the clients all over the world since its inception. We provide premium services to augment your web presence. Whether you are launching your business for the first time or trying to bring your organization on a virtual platform online or even for enhancing your company’s present situation, Tangle Idea is there for all your web related issues. You will get the website design just as you have visualized it. We are there to transform your vision into reality that too within a specified time limit. </p>
<a class="btn btn-green-border btn-lg" href="about_us">READ MORE</a>
</div>

<div class="clear"></div>
</div>
</section>
<section id="service">
<div class="container">
<div class="tittle">
<h2> Services of website development company </h2>
<hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
<p>Turn your business into next level with our creative and innovative IT solutions.</p>
</div>
<div class="col-md-4">
<ul class="services-wrap">
<li>
<div class="icons"> <a href="web-design-development-services"> <i class="fa fa-desktop fa-2x" aria-hidden="true"></i></a></div>
<div class="service-content services-home clearfix"> <a href="web-design-development-services">
<h5>Web Design &amp; Development</h5>
</a>
<p>Tangle Idea, web development company in Kolkata offers best website design solutions.</p>
<p><a href="web-design-development-services" class="view_more"> View Details </a></p>
</div>
</li>
<li>
<div class="icons"> <a href=""><i class="fa fa-mobile fa-2x" aria-hidden="true"></i></a> </div>
<div class="service-content services-home clearfix mob" style="padding-left:10px;padding-right:10px"> <a href="web-design-development-services">
<h5>Mobile App Development</h5>
</a>
<p>Maximize your commercial success by using our excellent app development services. </p>
<p><a href="" class="view_more"> View Details </a></p>
</div>
</li>
<div class="clear"></div>
</ul>
</div>
<div class="col-md-4">
<ul class="services-wrap">
<li>
<div class="icons"> <a href="ecommerce-web-development"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i></a> </div>
<div class="service-content services-home clearfix"> <a href="web-design-development-services">
<h5>Ecommerce Development</h5>
</a>
<p> Today's competitive eCommerce business Tangle Idea always adds innovative business idea. </p>
<p><a href="ecommerce-web-development" class="view_more"> View Details </a></p>
</div>
</li>
<li>
<div class="icons"> <a href="hire-seo-expert"><i class="fa fa-globe fa-2x" aria-hidden="true"></i></a> </div>
<div class="service-content services-home clearfix out"> <a href="hire-seo-expert">
<h5>Dedicated Resources</h5>
</a>
<p> Hire dedicated SEO Expert
from Tangle Idea and manage multiple website easily</p>
<p><a href="hire-seo-expert" class="view_more"> View Details </a></p>
</div>
</li>
</ul>
</div>
<div class="col-md-4">
<ul class="services-wrap">
<li>
<div class="icons"> <a href="software-development-company"><i class="fa fa-chrome fa-2x" aria-hidden="true"></i></a> </div>
<div class="service-content services-home clearfix soft"> <a href="web-design-development-services">
<h5>Software Development</h5>
</a>
<p> Tangle Idea is specialized for Custom Software Solutions for all sectors.</p>
<p><a href="software-development-company" class="view_more"> View Details </a></p>
</div>
</li>
<li>
<div class="icons"> <a href="seo-services"><i class="fa fa-search-plus fa-2x" aria-hidden="true"></i></a> </div>
<div class="service-content services-home clearfix seo"> <a href="seo-services">
<h5>SEO Services</h5>
</a>
<p> We have our own ethical high technique SEO strategy to provide effective online.</p>
<p><a href="seo-services" class="view_more"> View Details </a></p>
</div>
</li>
<div class="clear"></div>
</ul>
</div>
<div class="clear"></div>
</div>
</section>
<section id="feature" data-stellar-background-ratio="0.2">
<div class="container">
<div class="col-lg-12">
<div class="tittle choose">
<h3> Why Tangle Idea as website design company in Kolkata</h3>
<hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
<p>we craft beautiful and mindblowing website and mobile app to promote your business</p>
</div>
<div class="row">
<div class="container-box">
<div class="no-space">
<div class="img-section">
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="team img-responsive" alt="Experienced Team ">
<p>Experienced Team</p>
</div>
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="price img-responsive" alt="Reasonable Price">
<p>Reasonable Price</p>
</div>
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="time img-responsive" alt="On time Delivery">
<p>On time Delivery </p>
</div>
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="support img-responsive" alt="24*7 Customer Support">
<p>24*7 Customer Support</p>
</div>
</div>
<div class="img-section">
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="work img-responsive" alt="Premium Quality Work">
<p>Premium Quality Work</p>
</div>
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="tech img-responsive" alt="Latest Technology">
<p>Latest Technology</p>
</div>
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="res img-responsive" alt="Mobile Responsive">
<p>100% Mobile Responsive</p>
</div>
<div class="col-md-3">
<img src="images/service/service_sprite.png" class="client img-responsive" alt="Satisfied Clients">
<p>Track Record of Satisfied Clients </p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section id="about" class="our-works home text-center">
<div class="tittle">
<h4>Some of our website design &amp; development work</h4>
<hr class="wow bounceInUp animated" data-wow-duration="1s" data-wow-delay="0.7s" style="visibility:visible;animation-duration:1s;animation-delay:.7s;animation-name:bounceInUp">
<p>We produce awesome work for our clients according to their budget and time frame</p>
</div>
<div class="portfolio-wrapper">
<div class="images"> <img src="images/slide/macbook-slider-stage.png" alt="work background" class="img-responsive"></div>
<div class="swiper-container">
<div class="swiper-wrapper">
<div class="swiper-slide"><img src="images/slide/slide111.jpg" alt="work 2" class="img-responsive"></div>
<div class="swiper-slide"><img src="images/slide/slide222.jpg" alt="work 3" class="img-responsive"></div>
<div class="swiper-slide"><img src="images/slide/slide333.jpg" alt="work 4" class="img-responsive"></div>
<div class="swiper-slide"><img src="images/slide/slide444.jpg" alt="work 5" class="img-responsive"></div>
</div>
<div class="swiper-pagination"></div>
</div>
</div>
<a class="btn" href="portfolio">View Portfolio</a>
</section>
<section id="contact">
<div class="overlay">
<div class="container">
<div class="col-lg-12">
<div class="tittle clients">
<h5>Happy Clients of IT company in the World</h5>
<hr class="wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.7s">
<p>What our clients say about Tangle Idea's contribution in IT industry!</p>
</div>

<!--
<div class="container testimonial-home">
<div class="row">
<div class="col-lg-12" id="text">
<div class="cd-testimonials-wrapper">
<!--   
<ul class="cd-testimonials">

<li>
<p>Dealing with Tangle Idea was a pleasure. This team responded quickly and efficiently to all my questions and created me a website that I am thrilled with. Despite the fact that we were only able to deal by email (as I was deployed on military operations and did not have access to a phone), his skills and in depth understanding meant that this was not a problem. I would recommend Tangle Idea to anyone who wants a professional and appealing website. Now that my small business has launched, I have had masses of compliments about my site. Thank you Tangle Idea! </p>

<!---
<div class="cd-author"> <img src="images/sprites.png" class="auth2" alt="Author image">
<ul class="cd-author-info">
<li>Georgina Wallington</li>
<li>Owner, Pretty Paper Pictures</li>
</ul>
</div>

---><!---
</li>
<li>
<p>When I hired this team, I was in little bit doubt. But after some time, I was amazed by this team and their dedication towards the project. They did a perfect job for my eCommerce site. Habibur and his team were absolutely fantastic during the development and testing phase. They are very patient, good listener and very good coder. Also they are focused on quality. I will strongly recommend this team for any project.</p>

<!---
<div class="cd-author"> <img src="images/sprites.png" class="auth3" alt="Author image">
<ul class="cd-author-info">
<li>Amit Biswas</li>
<li>Owner, SoftMagic Technologies</li>
</ul>
</div>
---><!---
</li>
<li>
<p>I happened to come across Tangle Idea through just dial and am very fortunate that i met them as they exactly understood my needs and delivered everything in time . The best part about them is the readiness to do revisions as per our demand . The dynamic pages created by them are extremely user-friendly and the look and feel of their websites are uber cool, I wish them all the success in their future endeavors</p>

<!---
<div class="cd-author"> <img src="images/sprites.png" class="auth4" alt="Author image">
<ul class="cd-author-info">
<li>Dr. Kamlesh Kothari</li>
<li>CEO, Aesthetica - chain of dental clinics</li>
</ul>
</div>
---><!---
</li>
<li>
<p>Very quick and attentive. Met deadline and was available whenever needed. Highly recommended! Awesome designer! "Awesome Developer! Always on time! Always does the best work! Would hire and work with again! Gets the job done on time always!" </p>

<!---
<div class="cd-author"> <img src="images/sprites.png" class="auth5" alt="Author image">
<ul class="cd-author-info">
<li>Tabish Masood</li>
<li>Owner, Clickonicks</li>
</ul>
</div>
---><!---
</li>
</ul>



<a href="" class="cd-see-all">View all</a> </div>
</div>
</div>
</div>
-->


<div class="clearfix"></div>
</div>
</div>
</div>
</section>
<section class="about">
<div class="container">
<div class="row">
<div class="col-md-12 text-center">
<p class="special-text">Transform and empower your <strong>business </strong>with our experienced <strong>strategists</strong>, <strong>creative designers,</strong> and <strong>skillful developers</strong>.</p>
<p class="special-text">We <strong>craft beautiful</strong>, <strong>fast loading</strong>, <strong>SEO friendly</strong> and secured website.
</p>
<p class="special-text">Would you like to <strong>work with us?</strong></p>

<?php include("include/footer.php");
		include("include/footer_botom.php"); ?>