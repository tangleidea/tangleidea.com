<?php include("include/header.php"); ?>

<link href="css/gallery.css" rel="stylesheet" type="text/css">
  <!--HOME START===========================================--> 
 <div class="inner-banner5">
            <div class="tittle">

                    <h1>Tangle Idea Latest Theme</h1>

            </div>
        </div>
  
   <section class="portfolio">
<div class="container">
    <div id="elastic_grid_demo">
    
        </div>
    </div>
    </section>


     <!--======= How we work=========-->


<ul id="rig">
    <li>
        <a class="rig-cell" href="tangle-theme\Groovin" target="_blank">
            <img class="rig-img" src="images/portfolio/eklachalo.jpg">
            <span class="rig-overlay"></span>
             <span class="rig-text" style="border:1px solid;">View Theme</span> 
            
             
        </a>
 <!--       <span class="rig-text" style="top:130px;"> <a href=""><input type="button" value="Download" style="border:1px solid; width: 100%;color: skyblue;"  /></a> </span>
 -->
    </li>
    <li>
        <a class="rig-cell" href="http://bitbuying.co/" target="_blank">
            <img class="rig-img" src="images/portfolio/Capture.jpg">
            <span class="rig-overlay"></span>
            <span class="rig-text">View Details</span>
        </a>
    </li>
    <li>
        <a class="rig-cell" href="http://indovedicguru.com/" target="_blank">
            <img class="rig-img" src="images/portfolio/indovedic.jpg">
            <span class="rig-overlay"></span>
            <span class="rig-text">View Details</span>
        </a>
    </li>
    <li>
        <a class="rig-cell" href="http://kashiflabour.co.in/" target="_blank">
            <img class="rig-img" src="images/portfolio/kashif.jpg">
            <span class="rig-overlay"></span>
            <span class="rig-text">View Details</span>
        </a>
    </li>
    <li>
        <a class="rig-cell" href="http://bitshopping.net/" target="_blank">
            <img class="rig-img" src="images/portfolio/bitshopping.jpg">
            <span class="rig-overlay"></span>
            <span class="rig-text">View Details</span>
        </a>
    </li>
    <li>
        <a class="rig-cell" href="http://ecallsolutionsonline.com/" target="_blank">
            <img class="rig-img" src="images/portfolio/ecall.jpg">
            <span class="rig-overlay"></span>
            <span class="rig-text">View Details</span>
        </a>
    </li>
   
</ul>
    
    

					

    
    <!--======= CONTACT US =========-->
   <section class="about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="special-text">Transform and empower your <strong>business </strong>with our experienced <strong>strategists</strong>, <strong>creative designers,</strong> and <strong>skillful developers</strong>.</p>
                        <p class="special-text">We <strong>craft beautiful</strong>, <strong>fast loading</strong>, <strong>SEO friendly</strong> and secured website.
                        </p>
                        <p class="special-text">Would you like to <strong>work with us?</strong> </p>

<?php include("include/footer.php");
		include("include/footer_botom.php"); ?>