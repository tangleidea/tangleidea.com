<?php include("include/header.php"); ?>
  <!--HOME START===========================================--> 
   <div class="inner-banner5">
            <div class="tittle">

                <h1>Terms And Condition</h1>

            </div>
        </div>
  
  
  
 
  <!-- BEGIN CONTACT US (map) SECTION -->
    <!--======= TEAM =========-->   
    <section  class="android">
  <div class="container"> 
    
    <!--======= TITTLE =========-->
    <div class="tittle">
      <h2 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s"></h2>
      <hr class="wow bounceInUp animated" data-wow-duration="1s" data-wow-delay="0.7s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.7s; animation-name: bounceInUp;">
    </div>
    
 



<div class="col-lg-12">
<div class="testimonials_wrap testimonial-home">
<h4> Backup restoration</h4>
 <p>If your account was cancelled or suspended for non-payment and you still need your data to take with you there is a charge for all inquiries regarding previous services and / or support. We generally keep backups available for a period of 30 days after account cancellation, but can provide no guarantees on the actual length of availability of a backup. </p>
 
 <h4> Web Hosting Services</h4>
 <p>Tangleidea Solutions has strict resource usage restrictions on Web Hosting Services. These are designed to maintain the integrity, security and performance of our web servers. Failure to abide by these restrictions may result in account suspension or termination without refund. </p>
 
  <p><i class="fa fa-check-square-o icon_right"></i>No script or piece of software may use 25% or more of system resources for 60 seconds or longer <br/>
        <i class="fa fa-check-square-o icon_right"></i>No user may have above 5,000 opened files at any moment (the limit does not apply to overall number of existing files, owned by the user)<br/>
        <i class="fa fa-check-square-o icon_right"></i>Running of public file exchange services is strictly prohibited  <br/>
       <i class="fa fa-check-square-o icon_right"></i>Running stand-alone, unattached server side processes/deamons is strictly prohibited<br/>
       <i class="fa fa-check-square-o icon_right"></i>Running any type of web spider / indexer (Google Cash / Ad Spy) is strictly prohibited
    </p>

 <h4> Disk Usage Provision</h4>
 <p>90% or more of your content on your website must be linked from an HTML or similarly coded web page where all content is freely available to the public. Your website consists of web pages of a standard design, essentially HTML based text and graphics. Downloadable files, media, streaming content or any file which consumes more than 500kb of space must not exceed 10% of your total used disk quota. </p>
 
 <h4> WordPress Usage & Modules</h4>
 <p>We do not allow any WordPress caching modules on our shared or reseller hosting services. WordPress caching modules continually cause server overload problems and are only allowed on VPS or dedicated hosting. </p>
 
 
 
</div>
	</div>

  </div>

</section>


    <!--======= RIGHTS =========-->
 <section class="about">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="special-text">Transform and empower your <strong>business </strong>with our experienced <strong>strategists</strong>, <strong>creative designers,</strong> and <strong>skillful developers</strong>.</p>
                        <p class="special-text">We <strong>craft beautiful</strong>, <strong>fast loading</strong>, <strong>SEO friendly</strong> and secured website.
                        </p>
                        <p class="special-text">Would you like to <strong>work with us?</strong> </p>


<?php include("include/footer.php");
		include("include/footer_botom.php"); ?>